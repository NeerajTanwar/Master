﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace MasterQ
{
    class Program
    {
        #region "Private Variables"

 
       static Classes.clsAttempt _clsAttempt = new Classes.clsAttempt();
        #endregion
        static void Main(string[] args)
        {

            //-----------------------------
            // Developer Note (Neer)
            //-------------------------------
            //I put Everything in the classes so that
            //My main class implementation can be clean
            // as Well as it can Acheive Encapsulation
            // It can be more Cleaner Due to Time Constraint. 
            //I avoid doing that
            //it Can also be achived by Dictionary
            // Add keys there and frequency and check for Keys.which can
            //Reduce time complexy to O(N)
            //Right now Code is working but More Cleaning and Managing can be done


            _clsAttempt.RecordAttempt();
           

        }
    }
}
