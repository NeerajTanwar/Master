﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MasterQ.Classes
{
    class ClsUserInput
    {
        public Char[] User_Input_Receiver()
        {
            try
            {
                Char[] Player_Number = new char[4];
                Console.WriteLine("{0}Enter your magical 4 numbers", Environment.NewLine);
                for (Int32 Index = 0; Index <= 3; Index++)
                {
                    Console.WriteLine(string.Format("Enter your {0} number :", (Index + 1)));

                    // Read char
                    char input = Console.ReadKey().KeyChar;

                    // Validate digit input
                    bool IsDigit = char.IsDigit(input);

                    while (!IsDigit)
                    {

                        Console.ForegroundColor = ConsoleColor.Red; // Reset red color 
                        Console.WriteLine("{1}Invalid input, please enter digit, enter Your {0} number : ", (Index + 1), Environment.NewLine);
                        Console.ForegroundColor = ConsoleColor.White; // Reset input color

                        // Read input
                        input = Console.ReadKey().KeyChar;

                        // validate input 
                        IsDigit = char.IsDigit(input);
                    }

                    // Store char
                    Player_Number[Index] = input;

                    Console.ReadLine();
                }
                return Player_Number;
            }
            catch (Exception Ex)
            {
                throw Ex;
            }

        }
    }
}
