﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MasterQ.Classes
{
    class ClsResultGenerator
    {
        private String Assign_Random_Number = "";
        private String User_Input_Number = "";
        private String Result = "";
        public bool Winning_Flag = false;
        ClsRandomNumberGenerator _clsRandom = new ClsRandomNumberGenerator();
        ClsUserInput _clsUserInput = new ClsUserInput();
        Char[] Random_Number;
        Char[] User_Input;

        /// <summary>
        /// Display result 
        /// minus (-) sign should be printed for every digit that is correct but in the wrong position,
        /// and a plus(+) sign should be printed for every digit that is both correct and in the correct position.
        /// </summary>
        /// <param name="User_Input"></param>
        /// <param name="Random_Number"></param>
        /// <returns></returns>
        
        public ClsResultGenerator ()
        {
            Random_Number = _clsRandom.Generate_Random_Number();
        }
        public String Get_User_Result()
        {
            try
            {
                AcceptUserInput();
                Result = String.Empty;
                Assign_Random_Number = new string(Random_Number);
                User_Input_Number = new string(User_Input);
                // matches result
                if (Assign_Random_Number == User_Input_Number)
                {
                    Result = "Whoooaaaaa You Won";
                    Winning_Flag = true;
                    return Result;
                }
                string plusResult = "";
                string minusResult = "";

                for (int iCount = 0; iCount <= 3; iCount++)
                {
                    // read char
                    Char a = User_Input[iCount];

                    // adding plus for correct at right place
                    if (a == Random_Number[iCount])
                    {
                        plusResult = plusResult + "+";
                    }
                    else
                    {
                        // reads index
                        int Index = Assign_Random_Number.IndexOf(a);
                        if (Index < 0)
                        {
                            continue;
                        }
                        if (iCount == Index)
                        {
                            // adding plus for correct at right place
                            plusResult = plusResult + "+";
                        }
                        else
                        {
                            // adding minus for correct at wrong place
                            minusResult = minusResult + "-";
                        }
                    }
                }
                // Result (+) First and followed by (-) 
                Result = string.Format("{0}{1}", plusResult, minusResult);
                return Result;
            }
            catch (Exception Ex)
            {
                throw Ex;
            }
        }
        private void AcceptUserInput()
        {
         User_Input=   _clsUserInput.User_Input_Receiver();
        }
    }
}