﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MasterQ.Classes
{
    class clsAttempt
    {
         Classes.ClsResultGenerator _clsResultGenerator = new Classes.ClsResultGenerator();
         Int32 Number_of_Attempt = 0;
         String User_Response = "y";
         char[] validContinueInput = { 'y', 'n' };

        public void RecordAttempt()
        {
            Console.WriteLine("Please enter your name: ");
            String Player_Name = Console.ReadLine();
            Console.WriteLine("{0} welcome to the world of Bar Code printing {1}", Player_Name, Environment.NewLine);

            for (Number_of_Attempt = 0; Number_of_Attempt < 10; Number_of_Attempt++)
            {
                if (User_Response == "y")
                {
                    

                    String Result = _clsResultGenerator.Get_User_Result();

                    
                    Console.Write(Environment.NewLine);
                    // Display result
                    Console.WriteLine("Your Result is: " + Result);
                    Console.WriteLine("Do You want to Play Again (y/n):");

                    //Read user input
                    char input = Console.ReadKey().KeyChar;

                    // Validate user input
                    while (!validContinueInput.Contains(input))
                    {

                        Console.ForegroundColor = ConsoleColor.Red; // Reset forecolor to red
                        Console.WriteLine("{0}Invalid input, please enter (y/n) to continue. :", Environment.NewLine);
                        Console.ForegroundColor = ConsoleColor.White; // Default forecolor

                        // Read input
                        input = Console.ReadKey().KeyChar;
                    }

                    // Store input
                    User_Response = Convert.ToString(input);
                }
                else
                {
                    break;
                }
            }
            if (_clsResultGenerator.Winning_Flag == false)
            {
                Console.WriteLine("{0}You Lost this Game. Good Luck Next Time", Environment.NewLine);
                Console.ReadLine();

            }
        }
    }
}
