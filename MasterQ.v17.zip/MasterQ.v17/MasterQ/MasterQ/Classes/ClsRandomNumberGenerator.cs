﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MasterQ.Classes
{

    #region "Developer Information and Contact Detail"
    //Name : Neer Tanwar(nTanwar@abc.com)
    //Employee ID: 38947 (436-474-4754)
    //Department: IT
    //Immediate Manager: JOSEPH BROWN
    #endregion


        /// <summary>
        /// Random number generator class
        /// </summary>
    class ClsRandomNumberGenerator
    {
        /// <summary>
        ///  Generate 4 digit random number
        /// </summary>
        /// <returns>char array</returns>
        public Char[] Generate_Random_Number()
        {
            try
            {                
                Random rnd = new Random();

                String Random_Number = "";
                for (int i = 0; i <= 3; i++)
                {
                    //Generate Random Number Range between 1 to 6
                    Random_Number = Random_Number + rnd.Next(1, 6);
                }
                return Random_Number.ToCharArray();
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

    }
}
